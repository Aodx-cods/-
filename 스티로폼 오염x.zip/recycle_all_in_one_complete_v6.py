# recycle_all_in_one_complete_v6.py
# ------------------------------------------------------------
# 재활용 쓰레기 분류 + 오염도 판정 올인원 버전 v6 WinError 5 해결 + 배경 제거 학습 + 정확도 우선
#
# 이 파일 하나만 실행하면 아래 작업을 자동으로 진행합니다.
#
#   1. 필요한 패키지 설치
#   2. 같은 폴더에 있는 ZIP 파일 확인
#   3. models/material_cls.pt, models/contamination_cls.pt가 없거나 학습 조건이 바뀌면 자동 학습
#   4. 학습 완료 후 Streamlit 앱 자동 실행
#   5. 이미지 업로드 / 카메라 촬영 / 실시간 웹캠으로 판정
#
# ZIP 파일명 예:
#   유리 오염0.zip
#   유리 오염x.zip
#   종이 오염0.zip
#   종이 오염x.zip
#   캔 오염0.zip
#   캔 오염x.zip
#   비닐 오염o.zip
#   스티로폼 오염0.zip
#   스티로폼 오염x.zip
#
# 파일명 규칙:
#   오염0 / 오염o / 오염O  -> dirty, 오염됨
#   오염x / 오염X          -> clean, 깨끗함
#
# 실행:
#   python recycle_all_in_one_complete_v6.py
#
# 권장 폴더 구조:
#   C:/Users/김민성/Downloads/
#   ├─ recycle_all_in_one_complete_v6.py
#   ├─ 유리 오염0.zip
#   ├─ 유리 오염x.zip
#   ├─ 종이 오염0.zip
#   ├─ 종이 오염x.zip
#   ├─ 캔 오염0.zip
#   ├─ 캔 오염x.zip
#   ├─ 비닐 오염o.zip
#   ├─ 스티로폼 오염0.zip
#   └─ 스티로폼 오염x.zip
#
# 주의:
#   - 첫 실행은 학습 때문에 시간이 걸립니다.
#   - 인터넷 연결이 필요할 수 있습니다. yolo11n-cls.pt를 처음 받을 때 필요합니다.
#   - 사진 하나에 물체 하나가 크게 보이는 방식에 최적화되어 있습니다.
#   - 학습 전처리에서 배경을 제거하고 쓰레기 물체 영역만 잘라 학습합니다.
#   - 배경 전등처럼 밝은 물체가 같이 보이면 사이드바의 배경 제거 옵션을 켜세요.
#   - 색깔만 외우지 않도록 학습 시 색상/밝기/회전/크기 증강을 적용합니다.
# ------------------------------------------------------------

import argparse
import importlib.util
import json
import os
import random
import shutil
import subprocess
import sys
import time
import zipfile
import stat
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ============================================================
# 기본 설정
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = BASE_DIR / "models"

def get_work_dir() -> Path:
    """학습용 임시 폴더를 정합니다.

    OneDrive/Desktop 안에서 바로 extracted 폴더를 지우면 Windows가 파일을 잠그는 경우가 있어
    WinError 5가 자주 납니다. 그래서 학습 중간 산출물은 LOCALAPPDATA 쪽에 만듭니다.
    모델 파일만 코드 폴더의 models에 저장합니다.
    """
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        return Path(local_appdata) / "RecycleClassifier" / "auto_train_output"
    return BASE_DIR / "auto_train_output"

WORK_DIR = get_work_dir()
FEEDBACK_DIR = BASE_DIR / "feedback_samples"

MATERIAL_MODEL_PATH = MODELS_DIR / "material_cls.pt"
CONTAMINATION_MODEL_PATH = MODELS_DIR / "contamination_cls.pt"
TRAIN_INFO_PATH = MODELS_DIR / "train_info.json"

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

MATERIAL_MAP = {
    "유리": "glass",
    "종이": "paper",
    "캔": "can",
    "비닐": "vinyl",
    "스티로폼": "styrofoam",
    "플라스틱": "plastic",
    "페트": "plastic",
}

MATERIAL_LABELS_KOR = {
    "glass": "유리",
    "paper": "종이",
    "can": "캔",
    "vinyl": "비닐",
    "styrofoam": "스티로폼",
    "plastic": "플라스틱",
    "unknown": "판정불가",
}

CONTAMINATION_LABELS_KOR = {
    "clean": "깨끗함",
    "dirty": "오염됨",
    "uncertain": "판정불가",
}

REQUIRED_PACKAGES = [
    ("cv2", "opencv-python"),
    ("numpy", "numpy"),
    ("pandas", "pandas"),
    ("PIL", "pillow"),
    ("streamlit", "streamlit"),
    ("ultralytics", "ultralytics"),
]


# ============================================================
# 패키지 설치
# ============================================================

def run_cmd(cmd: List[str]) -> None:
    print("\n[실행]", " ".join(cmd))
    subprocess.check_call(cmd)


def ensure_packages() -> None:
    missing = []

    for module_name, package_name in REQUIRED_PACKAGES:
        if importlib.util.find_spec(module_name) is None:
            missing.append(package_name)

    if not missing:
        return

    print("[설치 필요] 다음 패키지를 설치합니다.")
    print(", ".join(missing))

    for package_name in missing:
        run_cmd([sys.executable, "-m", "pip", "install", package_name])


# 패키지 설치
ensure_packages()


# 패키지 import
import cv2
import numpy as np
import pandas as pd
import streamlit as st
from PIL import Image

try:
    from ultralytics import YOLO
except Exception:
    YOLO = None


# ============================================================
# Streamlit 자동 실행
# ============================================================

def is_running_in_streamlit() -> bool:
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        return get_script_run_ctx() is not None
    except Exception:
        return False


# ============================================================
# 학습 데이터 생성
# ============================================================

def safe_mkdir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _on_rm_error(func, path, exc_info) -> None:
    """Windows/OneDrive가 읽기 전용으로 잠근 파일을 지울 때 재시도합니다."""
    try:
        os.chmod(path, stat.S_IWRITE)
        func(path)
    except Exception:
        pass


def safe_rmtree(path: Path, retries: int = 5, delay: float = 0.4) -> None:
    """폴더 삭제를 안전하게 시도합니다.

    삭제가 실패하면 잠깐 기다렸다가 재시도합니다. 그래도 실패하면 폴더 이름을
    old_타임스탬프로 바꿔두고 새 학습 폴더를 만들 수 있게 합니다.
    """
    if not path.exists():
        return
    last_error: Optional[Exception] = None
    for _ in range(retries):
        try:
            shutil.rmtree(path, onerror=_on_rm_error)
            return
        except Exception as e:
            last_error = e
            time.sleep(delay)

    # 마지막 수단: 삭제 대신 이름을 바꿔 새 폴더 생성이 가능하게 합니다.
    backup = path.with_name(f"{path.name}_old_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
    try:
        if backup.exists():
            shutil.rmtree(backup, onerror=_on_rm_error)
        path.rename(backup)
        print(f"[경고] 기존 학습 폴더 삭제가 어려워 이름만 변경했습니다: {backup}")
        return
    except Exception:
        raise PermissionError(
            f"학습 임시 폴더를 삭제/이름변경하지 못했습니다: {path}\n"
            f"원인: {last_error}\n"
            "해결: Streamlit/탐색기/이미지 뷰어를 닫고 다시 실행하거나, "
            "OneDrive 폴더가 아닌 C:/RecycleTrain 같은 일반 폴더에서 실행하세요."
        )


def reset_dir(path: Path) -> None:
    safe_rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def parse_material_and_contamination(zip_name: str) -> Tuple[str, Optional[str]]:
    """ZIP 파일명에서 재질과 오염도를 읽습니다.

    지원 예시:
      - 비닐.zip, 종이.zip, 유리.zip -> clean으로 학습
      - 플라스틱 오염.zip, 비닐 오염0.zip, 캔 오염o.zip -> dirty로 학습
      - 종이 오염x.zip -> clean으로 학습
      - 캔 + 오염 캔.zip처럼 깨끗한 사진과 오염 사진이 섞인 이름은
        재질 학습에는 포함하되 오염도 학습에서는 제외합니다.
    """
    lower = zip_name.lower().replace(" ", "")

    material = None
    # 긴 키워드부터 검사해서 "페트"/"플라스틱" 같은 중복을 안정적으로 처리합니다.
    for kor, eng in sorted(MATERIAL_MAP.items(), key=lambda x: len(x[0]), reverse=True):
        if kor in zip_name:
            material = eng
            break

    if material is None:
        raise ValueError(f"파일명에서 재질을 찾지 못했습니다: {zip_name}")

    mixed_markers = ["+", "혼합", "섞", "mixed"]
    is_mixed = any(marker in lower for marker in mixed_markers)

    if "오염x" in lower or "오염없" in lower or "깨끗" in lower or "clean" in lower:
        contamination: Optional[str] = "clean"
    elif "오염" in lower or "dirty" in lower or "contaminated" in lower:
        contamination = None if is_mixed else "dirty"
    else:
        # 새로 올린 비닐.zip/종이.zip/유리.zip처럼 오염 표시가 없으면 깨끗한 샘플로 간주합니다.
        contamination = "clean"

    return material, contamination


def safe_extract_zip(zip_path: Path, extract_dir: Path) -> List[Path]:
    extract_dir.mkdir(parents=True, exist_ok=True)
    extracted_images: List[Path] = []

    with zipfile.ZipFile(zip_path, "r") as z:
        for member in z.infolist():
            if member.is_dir():
                continue

            suffix = Path(member.filename).suffix.lower()
            if suffix not in IMAGE_EXTS:
                continue

            safe_name = Path(member.filename).name
            if not safe_name:
                continue

            target = extract_dir / safe_name

            if target.exists():
                stem = target.stem
                ext = target.suffix
                i = 1
                while True:
                    candidate = extract_dir / f"{stem}_{i}{ext}"
                    if not candidate.exists():
                        target = candidate
                        break
                    i += 1

            with z.open(member, "r") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)

            extracted_images.append(target)

    return extracted_images


# ============================================================
# 학습 이미지 전처리: 배경 제거 + 쓰레기 영역만 crop
# ============================================================

def imread_unicode(path: Path) -> Optional[np.ndarray]:
    """한글 경로에서도 안전하게 이미지를 읽습니다."""
    try:
        data = np.fromfile(str(path), dtype=np.uint8)
        if data.size == 0:
            return None
        img = cv2.imdecode(data, cv2.IMREAD_COLOR)
        return img
    except Exception:
        return None


def imwrite_unicode(path: Path, image_bgr: np.ndarray) -> bool:
    """한글 경로에서도 안전하게 이미지를 저장합니다."""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        ext = path.suffix.lower()
        if ext not in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
            ext = ".jpg"
        ok, buf = cv2.imencode(ext, image_bgr)
        if not ok:
            return False
        buf.tofile(str(path))
        return True
    except Exception:
        return False


def resize_for_preprocess(image_bgr: np.ndarray, max_side: int = 1100) -> Tuple[np.ndarray, float]:
    h, w = image_bgr.shape[:2]
    side = max(h, w)
    if side <= max_side:
        return image_bgr, 1.0
    scale = max_side / float(side)
    resized = cv2.resize(image_bgr, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    return resized, scale


def make_square_on_neutral_background(image_bgr: np.ndarray, size: int = 640) -> np.ndarray:
    """분류 모델이 배경비율/이미지비율을 외우지 않도록 정사각 캔버스에 배치합니다."""
    if image_bgr.size == 0:
        return image_bgr
    h, w = image_bgr.shape[:2]
    scale = min(size / max(w, 1), size / max(h, 1)) * 0.92
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    resized = cv2.resize(image_bgr, (nw, nh), interpolation=cv2.INTER_AREA)
    canvas = np.full((size, size, 3), 245, dtype=np.uint8)
    x = (size - nw) // 2
    y = (size - nh) // 2
    canvas[y:y + nh, x:x + nw] = resized
    return canvas


def remove_background_for_training(image_bgr: np.ndarray) -> Tuple[np.ndarray, str]:
    """학습용 이미지에서 배경을 제거하고 쓰레기 물체 후보만 남깁니다.

    별도 세그멘테이션 모델 없이 OpenCV GrabCut, 가장자리, 색/밝기 차이를 조합합니다.
    완벽한 배경 제거는 아니지만, 모델이 벽/책상/전등을 같이 학습하는 문제를 줄입니다.
    실패하면 원본을 정사각 캔버스에 올려 반환합니다.
    """
    if image_bgr is None or image_bgr.size == 0:
        return image_bgr, "empty"

    work, _ = resize_for_preprocess(image_bgr)
    h, w = work.shape[:2]
    if h < 40 or w < 40:
        return make_square_on_neutral_background(work), "too_small_square"

    # 1) GrabCut: 대부분의 학습 사진은 쓰레기가 중앙에 있다는 가정.
    margin_x = max(2, int(w * 0.04))
    margin_y = max(2, int(h * 0.04))
    rect = (margin_x, margin_y, max(2, w - margin_x * 2), max(2, h - margin_y * 2))
    gc_mask = np.zeros((h, w), np.uint8)
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(work, gc_mask, rect, bgd, fgd, 5, cv2.GC_INIT_WITH_RECT)
        fg_mask = np.where((gc_mask == cv2.GC_FGD) | (gc_mask == cv2.GC_PR_FGD), 255, 0).astype("uint8")
    except Exception:
        fg_mask = np.zeros((h, w), np.uint8)

    # 2) 네 모서리 배경색과 다른 픽셀을 후보로 추가합니다.
    lab = cv2.cvtColor(work, cv2.COLOR_BGR2LAB)
    corner = max(8, int(min(h, w) * 0.08))
    corner_pixels = np.concatenate([
        lab[:corner, :corner].reshape(-1, 3),
        lab[:corner, w - corner:].reshape(-1, 3),
        lab[h - corner:, :corner].reshape(-1, 3),
        lab[h - corner:, w - corner:].reshape(-1, 3),
    ], axis=0)
    bg_color = np.median(corner_pixels, axis=0)
    diff = np.linalg.norm(lab.astype(np.float32) - bg_color.astype(np.float32), axis=2)
    diff_mask = (diff > 12).astype("uint8") * 255

    # 3) 투명 플라스틱/비닐처럼 배경색과 비슷해도 주름/경계가 많은 물체를 살립니다.
    gray = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(work, cv2.COLOR_BGR2HSV)
    _, s, v = cv2.split(hsv)
    edges = cv2.Canny(gray, 35, 120)
    edge_mask = cv2.dilate(edges, np.ones((5, 5), np.uint8), iterations=2)
    sat_mask = ((s > 28) & (v > 35)).astype("uint8") * 255

    mask = cv2.bitwise_or(fg_mask, diff_mask)
    mask = cv2.bitwise_or(mask, edge_mask)
    mask = cv2.bitwise_or(mask, sat_mask)

    # 매우 밝고 무늬 없는 배경은 약하게 제거합니다. 단, 투명병 하이라이트는 edge_mask가 살립니다.
    flat_bright_bg = ((v > 242) & (s < 25) & (edge_mask == 0)).astype("uint8") * 255
    mask = cv2.bitwise_and(mask, cv2.bitwise_not(flat_bright_bg))

    kernel = np.ones((7, 7), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=1)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return make_square_on_neutral_background(work), "no_contour_square"

    img_area = float(h * w)
    cx, cy = w / 2.0, h / 2.0
    best = None
    best_score = -1.0
    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        area = float(bw * bh)
        if area < img_area * 0.015:
            continue
        obj_cx, obj_cy = x + bw / 2.0, y + bh / 2.0
        dist = ((obj_cx - cx) ** 2 + (obj_cy - cy) ** 2) ** 0.5 / max(w, h)
        fill = cv2.contourArea(c) / max(area, 1.0)
        score = (area / img_area) - dist * 0.35 + min(fill, 1.0) * 0.12
        if score > best_score:
            best_score = score
            best = (x, y, x + bw, y + bh)

    if best is None:
        return make_square_on_neutral_background(work), "no_good_contour_square"

    x1, y1, x2, y2 = best
    pad = int(max(x2 - x1, y2 - y1) * 0.10)
    x1, y1 = max(0, x1 - pad), max(0, y1 - pad)
    x2, y2 = min(w, x2 + pad), min(h, y2 + pad)
    if x2 <= x1 or y2 <= y1:
        return make_square_on_neutral_background(work), "bad_box_square"

    crop = work[y1:y2, x1:x2]
    crop_mask = mask[y1:y2, x1:x2]

    # 배경은 중립색으로 바꿔 모델이 촬영 장소를 외우지 못하게 합니다.
    neutral = np.full_like(crop, 245)
    soft = cv2.GaussianBlur(crop_mask, (5, 5), 0).astype(np.float32) / 255.0
    soft = soft[:, :, None]
    cut = (crop.astype(np.float32) * soft + neutral.astype(np.float32) * (1.0 - soft)).astype(np.uint8)
    square = make_square_on_neutral_background(cut)
    return square, "background_removed_square"


def preprocess_training_image(src: Path, dst: Path, remove_background: bool = True) -> bool:
    img = imread_unicode(src)
    if img is None:
        return False
    if remove_background:
        processed, mode = remove_background_for_training(img)
    else:
        processed, mode = make_square_on_neutral_background(img), "square_only"
    ok = imwrite_unicode(dst, processed)
    if ok:
        meta = dst.with_suffix(dst.suffix + ".txt")
        try:
            meta.write_text(mode, encoding="utf-8")
        except Exception:
            pass
    return ok


def copy_split_images(
    images: List[Path],
    class_name: str,
    dataset_root: Path,
    train_ratio: float,
    seed: int,
    remove_background: bool = True,
) -> None:
    rng = random.Random(seed)
    images = images[:]
    rng.shuffle(images)

    split_index = int(len(images) * train_ratio)
    train_images = images[:split_index]
    val_images = images[split_index:]

    if len(images) >= 2 and not val_images:
        val_images = [train_images.pop()]

    for split_name, split_images in [("train", train_images), ("val", val_images)]:
        out_dir = dataset_root / split_name / class_name
        out_dir.mkdir(parents=True, exist_ok=True)

        for src in split_images:
            dst = out_dir / src.name
            if dst.exists():
                dst = out_dir / f"{src.stem}_{random.randint(10000, 99999)}{src.suffix}"
            ok = preprocess_training_image(src, dst, remove_background=remove_background)
            if not ok:
                print(f"[경고] 학습 이미지 전처리 실패: {src}")


def build_datasets_from_zips(
    zip_dir: Path,
    work_dir: Path,
    train_ratio: float = 0.8,
    seed: int = 42,
) -> Tuple[Path, Path, Dict[str, int], Dict[str, int]]:
    raw_dir = work_dir / "extracted"
    material_dataset = work_dir / "material_dataset"
    contamination_dataset = work_dir / "contamination_dataset"

    reset_dir(raw_dir)
    reset_dir(material_dataset)
    reset_dir(contamination_dataset)

    print(f"[학습 임시 폴더] {work_dir}")

    zip_files = sorted(zip_dir.glob("*.zip"))

    if not zip_files:
        raise FileNotFoundError(f"ZIP 파일을 찾지 못했습니다: {zip_dir}")

    material_counts: Dict[str, int] = {}
    contamination_counts: Dict[str, int] = {}

    for zip_path in zip_files:
        try:
            material, contamination = parse_material_and_contamination(zip_path.name)
        except ValueError:
            print(f"[건너뜀] 이름 규칙에 맞지 않는 ZIP: {zip_path.name}")
            continue

        group_dir = raw_dir / zip_path.stem
        images = safe_extract_zip(zip_path, group_dir)

        if not images:
            print(f"[경고] 이미지가 없습니다: {zip_path.name}")
            continue

        contamination_text = contamination if contamination is not None else "mixed/skip"
        print(f"[압축 해제] {zip_path.name} -> {len(images)}장 / 재질={material} / 오염도={contamination_text}")

        copy_split_images(
            images=images,
            class_name=material,
            dataset_root=material_dataset,
            train_ratio=train_ratio,
            seed=seed,
        )

        if contamination is not None:
            copy_split_images(
                images=images,
                class_name=contamination,
                dataset_root=contamination_dataset,
                train_ratio=train_ratio,
                seed=seed,
            )
            contamination_counts[contamination] = contamination_counts.get(contamination, 0) + len(images)
        else:
            print(f"[오염도 학습 제외] {zip_path.name}: clean/dirty가 섞였을 가능성이 있어 재질 학습에만 사용합니다.")

        material_counts[material] = material_counts.get(material, 0) + len(images)

    # 사용 중 틀린 결과를 저장한 feedback_samples도 다음 학습에 자동으로 포함합니다.
    # 구조: feedback_samples/<material>/<contamination>/*.jpg
    if FEEDBACK_DIR.exists():
        feedback_added = 0
        for material_dir in FEEDBACK_DIR.iterdir():
            if not material_dir.is_dir():
                continue
            material = normalize_material(material_dir.name)
            if material == "unknown":
                continue
            for contamination_dir in material_dir.iterdir():
                if not contamination_dir.is_dir():
                    continue
                contamination = normalize_contamination(contamination_dir.name)
                if contamination == "uncertain":
                    continue
                images = [x for x in contamination_dir.iterdir() if x.suffix.lower() in IMAGE_EXTS]
                if not images:
                    continue
                copy_split_images(images, material, material_dataset, train_ratio, seed)
                copy_split_images(images, contamination, contamination_dataset, train_ratio, seed)
                material_counts[material] = material_counts.get(material, 0) + len(images)
                contamination_counts[contamination] = contamination_counts.get(contamination, 0) + len(images)
                feedback_added += len(images)
        if feedback_added:
            print(f"[피드백 데이터 포함] {feedback_added}장")

    if not material_counts:
        raise RuntimeError("학습에 사용할 이미지가 없습니다. ZIP 파일명 규칙을 확인하세요.")

    balance_train_split(material_dataset, seed=seed)
    balance_train_split(contamination_dataset, seed=seed)

    return material_dataset, contamination_dataset, material_counts, contamination_counts


def print_counts(title: str, counts: Dict[str, int]) -> None:
    print(f"\n[{title}]")
    for k, v in sorted(counts.items()):
        print(f"  {k}: {v}장")


def balance_train_split(dataset_root: Path, seed: int = 42) -> None:
    """클래스별 학습 장수 차이가 너무 클 때 train 폴더만 복제해 균형을 맞춥니다.

    검증(val) 데이터는 건드리지 않습니다. 이 작업은 소수 클래스가 학습 중 거의
    보이지 않는 문제를 줄이기 위한 단순 oversampling입니다.
    """
    train_root = dataset_root / "train"
    if not train_root.exists():
        return

    class_dirs = [p for p in train_root.iterdir() if p.is_dir()]
    counts = {p.name: len([x for x in p.iterdir() if x.suffix.lower() in IMAGE_EXTS]) for p in class_dirs}
    counts = {k: v for k, v in counts.items() if v > 0}
    if len(counts) < 2:
        return

    target = max(counts.values())
    rng = random.Random(seed)
    for class_name, count in counts.items():
        if count >= target:
            continue
        folder = train_root / class_name
        originals = [x for x in folder.iterdir() if x.suffix.lower() in IMAGE_EXTS]
        need = target - count
        for i in range(need):
            src = rng.choice(originals)
            dst = folder / f"_balance_{i:05d}_{src.name}"
            shutil.copyfile(src, dst)
        print(f"[학습 데이터 균형 보정] {dataset_root.name}/{class_name}: {count}장 -> {target}장")


def train_cls_model(
    dataset_dir: Path,
    project_dir: Path,
    run_name: str,
    epochs: int,
    imgsz: int,
    batch: int,
    base_model: str,
    patience: int = 15,
) -> Path:
    if YOLO is None:
        raise RuntimeError("ultralytics YOLO를 불러오지 못했습니다.")

    model = YOLO(base_model)

    # 색깔만 보고 외우는 것을 줄이기 위해 색상/밝기/회전/크기 증강을 강하게 적용합니다.
    # patience로 성능 개선이 멈추면 조기 종료하여 학습 시간을 줄입니다.
    model.train(
        data=str(dataset_dir),
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        project=str(project_dir),
        name=run_name,
        exist_ok=True,
        patience=patience,
        cache=True,
        workers=0,
        optimizer="auto",
        cos_lr=True,
        augment=True,
        hsv_h=0.05,
        hsv_s=0.80,
        hsv_v=0.65,
        degrees=18.0,
        translate=0.12,
        scale=0.40,
        shear=5.0,
        fliplr=0.50,
        erasing=0.30,
    )

    best = project_dir / run_name / "weights" / "best.pt"

    if not best.exists():
        candidates = list(project_dir.glob("**/weights/best.pt"))
        if candidates:
            best = max(candidates, key=lambda p: p.stat().st_mtime)

    if not best.exists():
        raise RuntimeError(f"학습 후 best.pt를 찾지 못했습니다: {run_name}")

    return best



def collect_training_sources(zip_dir: Path) -> List[Dict[str, object]]:
    """학습에 사용할 ZIP/피드백 데이터의 현재 상태를 기록합니다."""
    sources: List[Dict[str, object]] = []
    for zip_path in sorted(zip_dir.glob("*.zip")):
        try:
            material, contamination = parse_material_and_contamination(zip_path.name)
        except Exception:
            material, contamination = "unknown", None
        stat = zip_path.stat()
        sources.append({
            "name": zip_path.name,
            "size": int(stat.st_size),
            "mtime": float(stat.st_mtime),
            "material": material,
            "contamination": contamination,
        })

    if FEEDBACK_DIR.exists():
        for img in sorted(FEEDBACK_DIR.rglob("*")):
            if img.is_file() and img.suffix.lower() in IMAGE_EXTS:
                stat = img.stat()
                sources.append({
                    "name": str(img.relative_to(BASE_DIR)),
                    "size": int(stat.st_size),
                    "mtime": float(stat.st_mtime),
                    "material": "feedback",
                    "contamination": "feedback",
                })
    return sources


def load_train_info() -> Dict[str, object]:
    if not TRAIN_INFO_PATH.exists():
        return {}
    try:
        return json.loads(TRAIN_INFO_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_train_info(info: Dict[str, object]) -> None:
    safe_mkdir(MODELS_DIR)
    TRAIN_INFO_PATH.write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")


def should_skip_training(zip_dir: Path, epochs: int, imgsz: int, batch: int, base_model: str, patience: int) -> Tuple[bool, str, List[Dict[str, object]]]:
    """기존 모델을 그대로 써도 되는지 판단합니다.

    예전 버전은 모델 파일만 있으면 무조건 학습을 건너뛰어서 새 ZIP을 추가해도
    epoch 로그가 안 뜨는 것처럼 보였습니다. 이제는 ZIP/피드백 데이터가 바뀌면
    자동으로 다시 학습합니다.
    """
    sources = collect_training_sources(zip_dir)

    if not MATERIAL_MODEL_PATH.exists() or not CONTAMINATION_MODEL_PATH.exists():
        return False, "모델 파일이 없어 학습이 필요합니다.", sources

    if not sources:
        return True, "ZIP 학습 자료가 없어 기존 모델을 사용합니다.", sources

    newest_source_mtime = max(float(s.get("mtime", 0.0)) for s in sources)
    oldest_model_mtime = min(MATERIAL_MODEL_PATH.stat().st_mtime, CONTAMINATION_MODEL_PATH.stat().st_mtime)
    if newest_source_mtime > oldest_model_mtime:
        return False, "새 ZIP/피드백 데이터가 모델보다 최신이라 다시 학습합니다.", sources

    prev = load_train_info()
    current_params = {
        "epochs": epochs,
        "imgsz": imgsz,
        "batch": batch,
        "base_model": base_model,
        "patience": patience,
    }
    if prev.get("params") != current_params:
        return False, "학습 설정이 바뀌어서 다시 학습합니다.", sources

    prev_sources = prev.get("sources")
    if prev_sources != sources:
        return False, "학습 자료 목록이 바뀌어서 다시 학습합니다.", sources

    return True, "기존 모델과 현재 ZIP 학습 자료가 같아서 학습을 건너뜁니다. 다시 학습하려면 --force-train을 붙이세요.", sources

def auto_train_if_needed(
    zip_dir: Path,
    epochs: int = 100,
    imgsz: int = 384,
    batch: int = 8,
    base_model: str = "yolo11s-cls.pt",
    force_train: bool = False,
    patience: int = 20,
) -> bool:
    safe_mkdir(MODELS_DIR)
    safe_mkdir(WORK_DIR)

    if not force_train:
        skip, reason, sources = should_skip_training(zip_dir, epochs, imgsz, batch, base_model, patience)
        print(f"[학습 필요 여부] {reason}")
        if sources:
            print("[인식된 ZIP/피드백 학습 자료]")
            for s in sources:
                if str(s.get("name", "")).lower().endswith(".zip"):
                    print(f"  - {s['name']} -> 재질={s.get('material')} / 오염도={s.get('contamination')}")
        if skip:
            print(MATERIAL_MODEL_PATH)
            print(CONTAMINATION_MODEL_PATH)
            return False

    zip_files = list(zip_dir.glob("*.zip"))
    if not zip_files:
        print("[경고] ZIP 파일이 없습니다. 학습을 건너뜁니다.")
        return False

    print("[자동 학습 시작]")
    print(f"ZIP 폴더: {zip_dir}")
    print(f"epochs: {epochs}")
    print(f"imgsz: {imgsz}")
    print(f"base_model: {base_model}")
    print(f"patience: {patience}")

    material_dataset, contamination_dataset, material_counts, contamination_counts = build_datasets_from_zips(
        zip_dir=zip_dir,
        work_dir=WORK_DIR,
        train_ratio=0.8,
        seed=42,
    )

    print_counts("재질 데이터 수", material_counts)
    print_counts("오염도 데이터 수", contamination_counts)

    print("\n[재질 분류 모델 학습 시작]")
    material_best = train_cls_model(
        dataset_dir=material_dataset,
        project_dir=WORK_DIR / "runs",
        run_name="material_cls_train",
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        base_model=base_model,
        patience=patience,
    )

    print("\n[오염도 분류 모델 학습 시작]")
    contamination_best = train_cls_model(
        dataset_dir=contamination_dataset,
        project_dir=WORK_DIR / "runs",
        run_name="contamination_cls_train",
        epochs=epochs,
        imgsz=imgsz,
        batch=batch,
        base_model=base_model,
        patience=patience,
    )

    shutil.copyfile(material_best, MATERIAL_MODEL_PATH)
    shutil.copyfile(contamination_best, CONTAMINATION_MODEL_PATH)

    save_train_info({
        "trained_at": datetime.now().isoformat(timespec="seconds"),
        "params": {
            "epochs": epochs,
            "imgsz": imgsz,
            "batch": batch,
            "base_model": base_model,
            "patience": patience,
        },
        "sources": collect_training_sources(zip_dir),
    })

    info = [
        "학습 완료 모델",
        f"재질 분류 모델: {MATERIAL_MODEL_PATH}",
        f"오염도 분류 모델: {CONTAMINATION_MODEL_PATH}",
        "",
        "재질 클래스:",
    ]

    for eng, kor in MATERIAL_LABELS_KOR.items():
        if eng != "unknown":
            info.append(f"- {eng}: {kor}")

    info.append("")
    info.append("오염도 클래스:")
    info.append("- clean: 깨끗함")
    info.append("- dirty: 오염됨")

    (MODELS_DIR / "class_info.txt").write_text("\n".join(info), encoding="utf-8")

    print("\n[자동 학습 완료]")
    print(MATERIAL_MODEL_PATH)
    print(CONTAMINATION_MODEL_PATH)

    return True


# ============================================================
# 앱 기능
# ============================================================

ROUTE_GUIDES = {
    "glass": {
        "clean": ("유리류", "깨끗한 유리로 추정됩니다. 내용물을 비우고 유리류로 배출하세요."),
        "dirty": ("세척 필요 / 유리류", "유리에 내용물이나 오염물이 있으면 헹군 뒤 유리류로 배출하세요."),
        "uncertain": ("유리류 수동 확인", "유리로 보이지만 오염 상태가 애매합니다. 내용물을 비우고 확인하세요."),
    },
    "paper": {
        "clean": ("종이류", "깨끗한 종이는 종이류로 배출하세요."),
        "dirty": ("오염 종이 / 일반 배출 확인", "음식물, 기름, 액체가 묻은 종이는 재활용이 어려울 수 있습니다."),
        "uncertain": ("종이류 수동 확인", "젖었거나 코팅된 종이는 지역 기준을 확인하세요."),
    },
    "can": {
        "clean": ("캔류", "깨끗한 캔으로 추정됩니다. 내용물을 비우고 캔류로 배출하세요."),
        "dirty": ("세척 필요 / 캔류", "캔 안의 내용물을 비우고 헹군 뒤 캔류로 배출하세요."),
        "uncertain": ("캔류 수동 확인", "캔으로 보이지만 오염 상태가 애매합니다. 내용물을 비우고 확인하세요."),
    },
    "vinyl": {
        "clean": ("비닐류", "깨끗한 비닐로 추정됩니다. 이물질을 제거하고 비닐류로 배출하세요."),
        "dirty": ("오염 비닐 / 일반 배출 확인", "음식물이나 기름이 묻은 비닐은 재활용이 어려울 수 있습니다."),
        "uncertain": ("비닐류 수동 확인", "비닐 상태가 애매합니다. 이물질 여부를 확인하세요."),
    },
    "styrofoam": {
        "clean": ("스티로폼류", "깨끗한 스티로폼으로 추정됩니다. 테이프와 이물질을 제거하고 배출하세요."),
        "dirty": ("오염 스티로폼 / 일반 배출 확인", "음식물이나 오염물이 묻은 스티로폼은 재활용이 어려울 수 있습니다."),
        "uncertain": ("스티로폼 수동 확인", "스티로폼 상태가 애매합니다. 이물질을 제거하고 확인하세요."),
    },
    "plastic": {
        "clean": ("플라스틱류", "깨끗한 플라스틱으로 추정됩니다. 라벨과 뚜껑은 지역 기준에 맞춰 분리하세요."),
        "dirty": ("세척 필요 / 플라스틱류", "플라스틱에 내용물이나 오염물이 있으면 헹군 뒤 플라스틱류로 배출하세요."),
        "uncertain": ("플라스틱류 수동 확인", "플라스틱으로 보이지만 오염 상태가 애매합니다. 내용물을 비우고 확인하세요."),
    },
    "unknown": {
        "clean": ("수동 확인", "재질이 애매합니다. 가까이서 다시 촬영하거나 수동으로 확인하세요."),
        "dirty": ("수동 확인", "재질이 애매하고 오염 가능성이 있습니다. 수동으로 확인하세요."),
        "uncertain": ("수동 확인", "재질과 오염도를 확실하게 판단하기 어렵습니다."),
    },
}


@dataclass
class AnalyzeResult:
    material: str
    material_confidence: float
    contamination: str
    contamination_confidence: float
    route: str
    guide: str
    method: str
    reason: str


def pil_to_bgr(image: Image.Image) -> np.ndarray:
    rgb = np.array(image.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def bgr_to_pil(image_bgr: np.ndarray) -> Image.Image:
    rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)


@st.cache_resource
def load_yolo_cls_model(path_text: str) -> Optional[object]:
    if YOLO is None:
        return None

    p = Path(path_text)
    if not p.exists():
        return None

    try:
        return YOLO(str(p))
    except Exception:
        return None


def get_center_roi_box(
    image_bgr: np.ndarray,
    roi_scale: float,
    roi_x_offset: float = 0.0,
    roi_y_offset: float = 0.0,
) -> Tuple[int, int, int, int]:
    h, w = image_bgr.shape[:2]
    side = int(min(w, h) * roi_scale)

    # 사용자가 물체를 화면 정중앙에 두기 어려운 경우가 많아서
    # 분석 박스 중심을 좌우/상하로 직접 조절할 수 있게 합니다.
    cx = int(w * (0.5 + roi_x_offset))
    cy = int(h * (0.5 + roi_y_offset))

    x1 = max(0, cx - side // 2)
    y1 = max(0, cy - side // 2)
    x2 = min(w, cx + side // 2)
    y2 = min(h, cy + side // 2)

    return x1, y1, x2, y2


def crop_roi(
    image_bgr: np.ndarray,
    roi_scale: float,
    roi_x_offset: float = 0.0,
    roi_y_offset: float = 0.0,
) -> Tuple[np.ndarray, Tuple[int, int, int, int]]:
    box = get_center_roi_box(image_bgr, roi_scale, roi_x_offset, roi_y_offset)
    x1, y1, x2, y2 = box
    crop = image_bgr[y1:y2, x1:x2]
    return crop, box


def _clip_box(box: Tuple[int, int, int, int], w: int, h: int) -> Tuple[int, int, int, int]:
    x1, y1, x2, y2 = box
    return max(0, x1), max(0, y1), min(w, x2), min(h, y2)


def find_object_crop(
    image_bgr: np.ndarray,
    roi_scale: float,
    roi_x_offset: float = 0.0,
    roi_y_offset: float = 0.0,
    use_object_crop: bool = True,
) -> Tuple[np.ndarray, Tuple[int, int, int, int], str]:
    """
    중앙 ROI 안에서 실제 물체처럼 보이는 영역만 다시 잘라냅니다.
    뒤쪽 전등처럼 작고 밝은 배경 물체가 분류에 끼어드는 문제를 줄이기 위한 전처리입니다.
    실패하면 기존 중앙 ROI를 그대로 사용합니다.
    """
    roi, roi_box = crop_roi(image_bgr, roi_scale, roi_x_offset, roi_y_offset)

    if not use_object_crop or roi.size == 0:
        return roi, roi_box, "중앙 영역 전체를 분석했습니다."

    rh, rw = roi.shape[:2]
    if rh < 40 or rw < 40:
        return roi, roi_box, "이미지가 작아 중앙 영역 전체를 분석했습니다."

    # 1차: GrabCut으로 중앙에 놓인 큰 전경 물체를 찾습니다.
    margin_x = max(2, int(rw * 0.08))
    margin_y = max(2, int(rh * 0.08))
    rect = (margin_x, margin_y, max(2, rw - margin_x * 2), max(2, rh - margin_y * 2))
    mask = np.zeros((rh, rw), np.uint8)
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)

    try:
        cv2.grabCut(roi, mask, rect, bgd, fgd, 3, cv2.GC_INIT_WITH_RECT)
        fg_mask = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype("uint8")
    except Exception:
        fg_mask = np.zeros((rh, rw), np.uint8)

    # 2차: 너무 밝은 전등/반사점은 후보에서 약하게 제외하고, 경계선/채도 정보를 보강합니다.
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    h, s, v = cv2.split(hsv)
    edges = cv2.Canny(gray, 40, 130)
    bright_lamp_like = ((v > 235) & (s < 55)).astype("uint8") * 255
    texture_mask = (((s > 35) & (v > 35)) | (edges > 0)).astype("uint8") * 255

    combined = cv2.bitwise_or(fg_mask, texture_mask)
    combined = cv2.bitwise_and(combined, cv2.bitwise_not(bright_lamp_like))
    kernel = np.ones((5, 5), np.uint8)
    combined = cv2.morphologyEx(combined, cv2.MORPH_CLOSE, kernel, iterations=2)
    combined = cv2.morphologyEx(combined, cv2.MORPH_OPEN, kernel, iterations=1)

    contours, _ = cv2.findContours(combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return roi, roi_box, "물체 영역을 찾지 못해 중앙 영역 전체를 분석했습니다."

    cx, cy = rw / 2.0, rh / 2.0
    best = None
    best_score = -1.0
    roi_area = float(rw * rh)

    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        area = float(bw * bh)
        if area < roi_area * 0.04:
            continue

        patch = roi[y:y + bh, x:x + bw]
        patch_gray = gray[y:y + bh, x:x + bw]
        patch_edges = edges[y:y + bh, x:x + bw]
        patch_hsv = hsv[y:y + bh, x:x + bw]
        edge_density = float(np.mean(patch_edges > 0))
        brightness_std = float(np.std(patch_gray))
        saturation_mean = float(np.mean(patch_hsv[:, :, 1]))

        # 벽/책상처럼 넓지만 무늬가 거의 없는 배경은 제외합니다.
        if edge_density < 0.015 and brightness_std < 18 and saturation_mean < 45:
            continue

        # 중앙과 가까운 큰 물체를 우선 선택합니다.
        # 단, 위쪽 배경보다 사용자가 들고 있는 물체가 자주 있는 아래쪽을 약간 우대합니다.
        obj_cx, obj_cy = x + bw / 2.0, y + bh / 2.0
        dist = ((obj_cx - cx) ** 2 + (obj_cy - cy) ** 2) ** 0.5 / max(rw, rh)
        lower_bonus = max(0.0, (obj_cy / max(rh, 1)) - 0.45) * 0.18
        texture_bonus = min(edge_density / 0.08, 1.0) * 0.12
        score = (area / roi_area) - dist * 0.55 + lower_bonus + texture_bonus
        if score > best_score:
            best_score = score
            best = (x, y, x + bw, y + bh)

    if best is None:
        return roi, roi_box, "큰 중앙 물체를 찾지 못해 중앙 영역 전체를 분석했습니다."

    x1, y1, x2, y2 = best
    pad = int(max(x2 - x1, y2 - y1) * 0.12)
    x1, y1, x2, y2 = _clip_box((x1 - pad, y1 - pad, x2 + pad, y2 + pad), rw, rh)

    rx1, ry1, _, _ = roi_box
    abs_box = (rx1 + x1, ry1 + y1, rx1 + x2, ry1 + y2)
    obj_crop = image_bgr[abs_box[1]:abs_box[3], abs_box[0]:abs_box[2]]

    if obj_crop.size == 0:
        return roi, roi_box, "물체 영역 자르기에 실패해 중앙 영역 전체를 분석했습니다."

    return obj_crop, abs_box, "배경을 제거하고 중앙의 큰 물체 영역만 분석했습니다."


def draw_roi(image_bgr: np.ndarray, box: Tuple[int, int, int, int], label: str) -> np.ndarray:
    out = image_bgr.copy()
    x1, y1, x2, y2 = box

    # OpenCV는 한글 표시가 깨질 수 있어 영어 라벨만 씁니다.
    cv2.rectangle(out, (x1, y1), (x2, y2), (0, 220, 0), 3)
    cv2.putText(
        out,
        label,
        (x1, max(30, y1 - 10)),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.75,
        (0, 220, 0),
        2,
        cv2.LINE_AA,
    )

    return out


def preprocess_crop(crop_bgr: np.ndarray) -> np.ndarray:
    if crop_bgr.size == 0:
        return crop_bgr

    lab = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    if np.mean(l) < 80:
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        lab = cv2.merge((l, a, b))
        crop_bgr = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    return crop_bgr


def predict_yolo_classification(model: Optional[object], crop_bgr: np.ndarray) -> Optional[Tuple[str, float]]:
    if model is None or crop_bgr.size == 0:
        return None

    rgb = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)

    try:
        results = model.predict(source=rgb, verbose=False)
    except Exception:
        return None

    if not results:
        return None

    result = results[0]

    if getattr(result, "probs", None) is None:
        return None

    try:
        idx = int(result.probs.top1)
        conf = float(result.probs.top1conf)
        names = result.names

        if isinstance(names, dict):
            label = str(names.get(idx, idx))
        elif isinstance(names, list):
            label = str(names[idx])
        else:
            label = str(idx)

        return label.lower().strip(), conf

    except Exception:
        return None


def normalize_material(label: str) -> str:
    l = label.lower().strip()

    if l in {"glass", "유리"}:
        return "glass"
    if l in {"paper", "종이", "cardboard", "carton"}:
        return "paper"
    if l in {"can", "캔", "metal", "aluminum", "aluminium"}:
        return "can"
    if l in {"vinyl", "비닐", "plastic_bag", "plastic bag"}:
        return "vinyl"
    if l in {"styrofoam", "스티로폼", "foam", "eps"}:
        return "styrofoam"
    if l in {"plastic", "플라스틱", "pet", "pet_bottle"}:
        return "plastic"

    return "unknown"


def normalize_contamination(label: str) -> str:
    l = label.lower().strip()

    if l in {"clean", "washed", "오염x", "x", "깨끗함"}:
        return "clean"
    if l in {"dirty", "contaminated", "unwashed", "오염0", "오염o", "o", "오염됨"}:
        return "dirty"

    return "uncertain"


def feature_material(crop_bgr: np.ndarray) -> Tuple[str, float, str]:
    hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)

    _, s, v = cv2.split(hsv)

    mean_s = float(np.mean(s))
    mean_v = float(np.mean(v))
    std_v = float(np.std(v))
    highlight_ratio = float(np.mean(v > 220))
    low_saturation_ratio = float(np.mean(s < 45))

    edges = cv2.Canny(gray, 50, 150)
    edge_ratio = float(np.mean(edges > 0))

    paper_score = low_saturation_ratio * 0.40 + min(mean_v / 215.0, 1.0) * 0.25 + (1.0 - min(edge_ratio / 0.20, 1.0)) * 0.35
    can_score = low_saturation_ratio * 0.32 + min(std_v / 85.0, 1.0) * 0.35 + min(highlight_ratio / 0.22, 1.0) * 0.33
    glass_score = min(highlight_ratio / 0.22, 1.0) * 0.38 + low_saturation_ratio * 0.20 + min(edge_ratio / 0.16, 1.0) * 0.42
    vinyl_score = min(mean_s / 100.0, 1.0) * 0.28 + min(edge_ratio / 0.22, 1.0) * 0.22 + min(highlight_ratio / 0.25, 1.0) * 0.30
    styrofoam_score = low_saturation_ratio * 0.40 + min(mean_v / 230.0, 1.0) * 0.30 + (1.0 - min(mean_s / 80.0, 1.0)) * 0.30
    plastic_score = min(mean_s / 110.0, 1.0) * 0.35 + (1.0 - min(can_score, 1.0)) * 0.20 + (1.0 - min(glass_score, 1.0)) * 0.20 + (1.0 - min(styrofoam_score, 1.0)) * 0.25

    scores: Dict[str, float] = {
        "paper": paper_score,
        "plastic": plastic_score,
        "can": can_score,
        "glass": glass_score,
        "vinyl": vinyl_score,
        "styrofoam": styrofoam_score,
    }

    material = max(scores, key=scores.get)
    sorted_scores = sorted(scores.values(), reverse=True)
    gap = sorted_scores[0] - sorted_scores[1]

    if gap < 0.035:
        return "unknown", 0.45, "모델이 없어서 보조 판정을 사용했지만 재질 특징이 애매합니다."

    conf = max(0.45, min(0.88, 0.50 + scores[material] * 0.30 + gap * 0.25))
    return material, conf, "모델이 없어서 색상, 반사, 밝기, 경계선 특징으로 보조 판정했습니다."


def pet_bottle_like_score(crop_bgr: np.ndarray) -> Tuple[float, str]:
    """투명 PET병을 유리로 오인하는 경우를 줄이기 위한 보조 점수입니다.

    분류 모델이 유리라고 해도, 파란/보라 계열 뚜껑 또는 푸른 PET병 색감,
    구겨진 주름 에지, 얇은 투명 플라스틱 질감이 강하면 plastic으로 보정합니다.
    """
    if crop_bgr.size == 0:
        return 0.0, ""

    hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)
    h, s, v = cv2.split(hsv)

    # PET 생수병에서 자주 보이는 옅은 파란색/청색 계열과 진한 뚜껑 후보.
    blue_tint_ratio = float(np.mean((h >= 85) & (h <= 135) & (s > 20) & (v > 90)))
    dark_blue_cap_ratio = float(np.mean((h >= 90) & (h <= 145) & (s > 55) & (v > 35) & (v < 210)))

    edges = cv2.Canny(gray, 45, 140)
    edge_ratio = float(np.mean(edges > 0))
    bright_ratio = float(np.mean(v > 210))
    low_sat_ratio = float(np.mean(s < 45))

    # 유리는 투명하고 반사가 있지만, PET병은 푸른 색감/뚜껑/주름 에지가 같이 나타나는 경우가 많습니다.
    score = 0.0
    score += min(blue_tint_ratio / 0.18, 1.0) * 0.35
    score += min(dark_blue_cap_ratio / 0.025, 1.0) * 0.30
    score += min(edge_ratio / 0.12, 1.0) * 0.20
    score += min(bright_ratio / 0.35, 1.0) * 0.10
    score += (1.0 - min(low_sat_ratio / 0.90, 1.0)) * 0.05

    reason = (
        f"PET 보정점수={score:.2f}, blue={blue_tint_ratio:.3f}, "
        f"cap={dark_blue_cap_ratio:.3f}, edge={edge_ratio:.3f}"
    )
    return score, reason


def correct_material_by_visual_rules(material: str, conf: float, crop_bgr: np.ndarray) -> Tuple[str, float, Optional[str]]:
    pet_score, pet_reason = pet_bottle_like_score(crop_bgr)

    # 플라스틱 병을 유리로 잘못 보는 문제가 가장 커서, 유리 예측일 때만 강하게 보정합니다.
    # 모델 신뢰도가 매우 높아도 PET 점수가 충분히 높으면 plastic으로 바꿉니다.
    if material == "glass" and pet_score >= 0.58:
        new_conf = max(0.62, min(0.84, 0.58 + pet_score * 0.25))
        return "plastic", new_conf, "투명하지만 PET병/플라스틱 병 특징이 강해서 유리 예측을 플라스틱으로 보정했습니다. " + pet_reason

    # 비닐/플라스틱이 종이로 오인될 때를 조금 완화합니다. 종이는 대체로 채도가 낮고 주름 반사가 덜합니다.
    if material == "paper" and pet_score >= 0.70:
        new_conf = max(0.60, min(0.80, 0.55 + pet_score * 0.22))
        return "plastic", new_conf, "종이 예측이지만 투명 플라스틱/PET 특징이 더 강해서 플라스틱으로 보정했습니다. " + pet_reason

    return material, conf, None


def feature_contamination(crop_bgr: np.ndarray, material: str) -> Tuple[str, float, str]:
    hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)

    h, s, v = cv2.split(hsv)

    dark_ratio = float(np.mean(v < 55))
    stain_ratio = float(np.mean((s > 85) & (v < 210)))

    brown_yellow = ((h >= 8) & (h <= 38) & (s > 55) & (v < 210))
    green = ((h >= 40) & (h <= 90) & (s > 50) & (v < 210))
    red1 = ((h >= 0) & (h <= 8) & (s > 55) & (v < 210))
    red2 = ((h >= 165) & (h <= 179) & (s > 55) & (v < 210))

    food_color_ratio = float(np.mean(brown_yellow | green | red1 | red2))

    height = crop_bgr.shape[0]
    lower = crop_bgr[int(height * 0.55):, :]
    lower_hsv = cv2.cvtColor(lower, cv2.COLOR_BGR2HSV)
    lower_s = lower_hsv[:, :, 1]
    lower_v = lower_hsv[:, :, 2]

    lower_dirty_ratio = float(np.mean((lower_v < 90) | ((lower_s > 80) & (lower_v < 210))))
    texture_score = min(float(np.std(gray)) / 90.0, 1.0)

    dirty_score = dark_ratio * 0.25 + stain_ratio * 0.25 + food_color_ratio * 0.25 + lower_dirty_ratio * 0.15 + texture_score * 0.10

    if material in {"paper", "vinyl", "styrofoam"}:
        dirty_threshold = 0.23
        clean_threshold = 0.13
    else:
        dirty_threshold = 0.30
        clean_threshold = 0.16

    if dirty_score >= dirty_threshold:
        return "dirty", min(0.90, 0.55 + dirty_score), "색 얼룩, 어두운 잔여물, 내용물 후보가 감지되었습니다."

    if dirty_score <= clean_threshold:
        return "clean", min(0.88, 0.65 + (clean_threshold - dirty_score)), "뚜렷한 음식물, 액체, 얼룩 후보가 적습니다."

    return "uncertain", 0.55, "오염 흔적이 약하게 보이지만 확실하지 않습니다."


def analyze_crop(
    crop_bgr: np.ndarray,
    material_model: Optional[object],
    contamination_model: Optional[object],
    min_model_conf: float,
) -> AnalyzeResult:
    crop_bgr = preprocess_crop(crop_bgr)

    material_pred = predict_yolo_classification(material_model, crop_bgr)

    if material_pred is not None:
        raw_label, conf = material_pred
        material = normalize_material(raw_label)

        if conf >= min_model_conf and material != "unknown":
            material_conf = conf
            material_method = "material_cls.pt"
            material_reason = f"재질 분류 모델이 {raw_label}로 판단했습니다."
        else:
            material, material_conf, material_reason = feature_material(crop_bgr)
            material_method = "feature"
            material_reason = f"모델 예측 {raw_label}의 신뢰도가 낮아 보조 판정을 사용했습니다. " + material_reason
    else:
        material, material_conf, material_reason = feature_material(crop_bgr)
        material_method = "feature"

    corrected_material, corrected_conf, correction_reason = correct_material_by_visual_rules(material, material_conf, crop_bgr)
    if correction_reason is not None:
        material = corrected_material
        material_conf = corrected_conf
        material_method = material_method + "+visual_rule"
        material_reason = material_reason + " " + correction_reason

    cont_pred = predict_yolo_classification(contamination_model, crop_bgr)

    if cont_pred is not None:
        raw_cont, cont_conf = cont_pred
        contamination = normalize_contamination(raw_cont)

        if cont_conf >= min_model_conf:
            contamination_conf = cont_conf
            contamination_method = "contamination_cls.pt"
            contamination_reason = f"오염도 분류 모델이 {raw_cont}로 판단했습니다."
        else:
            contamination, contamination_conf, contamination_reason = feature_contamination(crop_bgr, material)
            contamination_method = "feature"
            contamination_reason = f"모델 예측 {raw_cont}의 신뢰도가 낮아 보조 판정을 사용했습니다. " + contamination_reason
    else:
        contamination, contamination_conf, contamination_reason = feature_contamination(crop_bgr, material)
        contamination_method = "feature"

    route, guide = ROUTE_GUIDES.get(material, ROUTE_GUIDES["unknown"]).get(
        contamination,
        ROUTE_GUIDES.get(material, ROUTE_GUIDES["unknown"])["uncertain"],
    )

    return AnalyzeResult(
        material=material,
        material_confidence=material_conf,
        contamination=contamination,
        contamination_confidence=contamination_conf,
        route=route,
        guide=guide,
        method=f"재질: {material_method} / 오염도: {contamination_method}",
        reason=material_reason + " " + contamination_reason,
    )


def display_result(result: AnalyzeResult) -> None:
    material_kor = MATERIAL_LABELS_KOR.get(result.material, result.material)
    contamination_kor = CONTAMINATION_LABELS_KOR.get(result.contamination, result.contamination)

    c1, c2, c3 = st.columns(3)

    with c1:
        st.metric("재질", material_kor, f"신뢰도 {result.material_confidence:.2f}")

    with c2:
        st.metric("오염도", contamination_kor, f"신뢰도 {result.contamination_confidence:.2f}")

    with c3:
        st.metric("배출 방법", result.route)

    if result.contamination == "dirty":
        st.error(result.guide)
    elif result.contamination == "clean":
        st.success(result.guide)
    else:
        st.warning(result.guide)

    st.caption("사용 방식: " + result.method)
    st.info("판정 근거: " + result.reason)

    df = pd.DataFrame([
        {"항목": "재질", "결과": material_kor, "신뢰도": round(result.material_confidence, 3)},
        {"항목": "오염도", "결과": contamination_kor, "신뢰도": round(result.contamination_confidence, 3)},
        {"항목": "배출 방법", "결과": result.route, "신뢰도": "-"},
    ])

    st.dataframe(df, use_container_width=True)


def save_feedback(image_bgr: np.ndarray, material: str, contamination: str) -> Path:
    out_dir = FEEDBACK_DIR / material / contamination
    safe_mkdir(out_dir)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    out_path = out_dir / f"{ts}.jpg"

    cv2.imwrite(str(out_path), image_bgr)
    return out_path


def analyze_and_show_image(
    pil_img: Image.Image,
    material_model: Optional[object],
    contamination_model: Optional[object],
    roi_scale: float,
    roi_x_offset: float,
    roi_y_offset: float,
    min_model_conf: float,
    use_object_crop: bool,
) -> None:
    image_bgr = pil_to_bgr(pil_img)

    crop, box, crop_reason = find_object_crop(image_bgr, roi_scale, roi_x_offset, roi_y_offset, use_object_crop)
    crop = preprocess_crop(crop)

    result = analyze_crop(
        crop_bgr=crop,
        material_model=material_model,
        contamination_model=contamination_model,
        min_model_conf=min_model_conf,
    )

    annotated = draw_roi(
        image_bgr,
        box,
        label=f"{result.material} / {result.contamination}",
    )

    left, right = st.columns(2)

    with left:
        st.caption("원본 이미지 + 실제 분석 박스")
        st.image(bgr_to_pil(annotated), use_container_width=True)

    with right:
        st.caption("실제로 모델에 넣은 이미지")
        st.image(bgr_to_pil(crop), use_container_width=True)

    st.caption(crop_reason)
    display_result(result)

    with st.expander("틀린 결과 저장하기"):
        st.write("결과가 틀렸다면 정답을 선택하고 저장하세요. 나중에 추가 학습 데이터로 사용할 수 있습니다.")

        c1, c2 = st.columns(2)

        with c1:
            correct_material = st.selectbox(
                "정답 재질",
                ["glass", "paper", "can", "vinyl", "styrofoam", "plastic", "unknown"],
                format_func=lambda x: MATERIAL_LABELS_KOR.get(x, x),
            )

        with c2:
            correct_contamination = st.selectbox(
                "정답 오염도",
                ["clean", "dirty", "uncertain"],
                format_func=lambda x: CONTAMINATION_LABELS_KOR.get(x, x),
            )

        if st.button("중앙 영역 이미지를 정답 데이터로 저장"):
            out = save_feedback(crop, correct_material, correct_contamination)
            st.success(f"저장 완료: {out}")


def show_model_status(material_model: Optional[object], contamination_model: Optional[object]) -> None:
    with st.expander("모델 상태"):
        if material_model is not None:
            st.success("재질 분류 모델 사용 중")
            st.code(str(MATERIAL_MODEL_PATH), language="text")
        else:
            st.warning("재질 분류 모델 없음. 보조 판정으로 작동합니다.")
            st.code(str(MATERIAL_MODEL_PATH), language="text")

        if contamination_model is not None:
            st.success("오염도 분류 모델 사용 중")
            st.code(str(CONTAMINATION_MODEL_PATH), language="text")
        else:
            st.warning("오염도 분류 모델 없음. 보조 판정으로 작동합니다.")
            st.code(str(CONTAMINATION_MODEL_PATH), language="text")


def sidebar_options() -> Tuple[float, float, float, float, bool]:
    with st.sidebar:
        st.header("성능 설정")

        roi_scale = st.slider(
            "분석 박스 크기",
            min_value=0.35,
            max_value=1.00,
            value=0.80,
            step=0.05,
            help="초록색 박스 안에 물체가 크게 들어오도록 조절하세요.",
        )

        roi_x_offset = st.slider(
            "분석 박스 좌우 이동",
            min_value=-0.35,
            max_value=0.35,
            value=0.00,
            step=0.05,
            help="음수는 왼쪽, 양수는 오른쪽으로 이동합니다.",
        )

        roi_y_offset = st.slider(
            "분석 박스 상하 이동",
            min_value=-0.35,
            max_value=0.35,
            value=0.10,
            step=0.05,
            help="음수는 위쪽, 양수는 아래쪽으로 이동합니다. 손에 들고 찍을 때는 약간 아래가 보통 더 좋습니다.",
        )

        min_model_conf = st.slider(
            "모델 최소 신뢰도",
            min_value=0.30,
            max_value=0.95,
            value=0.60,
            step=0.05,
            help="값을 올리면 애매한 결과를 덜 믿습니다. 비닐을 종이로 과감하게 말할 때는 0.60~0.75가 낫습니다.",
        )

        use_object_crop = st.checkbox(
            "자동 물체 영역 찾기(실험적)",
            value=False,
            help="초록 박스가 이상한 벽/전등을 잡으면 끄세요. 기본은 직접 조절한 분석 박스 전체를 분류합니다.",
        )

        st.divider()
        st.info("초록색 박스가 실제 재활용품을 크게 덮도록 크기와 위치를 먼저 맞추세요. 자동 물체 영역 찾기는 실패할 수 있어 기본값을 꺼두었습니다.")

    return roi_scale, roi_x_offset, roi_y_offset, min_model_conf, use_object_crop

def streamlit_app() -> None:
    st.set_page_config(
        page_title="재활용 올인원 분류 v4 완전판",
        page_icon="♻️",
        layout="wide",
    )

    safe_mkdir(MODELS_DIR)
    safe_mkdir(FEEDBACK_DIR)

    roi_scale, roi_x_offset, roi_y_offset, min_model_conf, use_object_crop = sidebar_options()

    material_model = load_yolo_cls_model(str(MATERIAL_MODEL_PATH))
    contamination_model = load_yolo_cls_model(str(CONTAMINATION_MODEL_PATH))

    st.title("♻️ 재활용 쓰레기 분류 + 오염도 판정 올인원 v4")

    st.write(
        "이 앱은 처음 실행할 때 ZIP 이미지로 자동 학습한 뒤, "
        "중앙 박스 안의 물체 하나를 분석합니다."
    )

    show_model_status(material_model, contamination_model)

    with st.expander("학습이 안 되는 것처럼 보일 때 확인"):
        st.write("이미 모델 파일이 있고 ZIP 학습 자료가 바뀌지 않았으면 학습을 건너뜁니다. 새 ZIP을 추가했거나 설정이 바뀌면 이 v4는 자동으로 다시 학습합니다.")
        st.code("python recycle_all_in_one_complete_v6.py --force-train", language="bash")
        st.code("python recycle_all_in_one_complete_v6.py --force-train --train-only", language="bash")
        st.caption("epoch 로그는 Streamlit 화면이 아니라 명령 프롬프트/터미널에 표시됩니다. --train-only를 쓰면 학습만 하고 앱은 열지 않습니다.")

    if material_model is None or contamination_model is None:
        st.error("학습 모델이 없습니다. 이 파일을 Streamlit이 아니라 `python recycle_all_in_one_complete_v6.py`로 실행하면 자동 학습 후 앱이 열립니다.")

        if st.button("앱 안에서 지금 자동 학습 시작"):
            with st.spinner("자동 학습 중입니다. 시간이 오래 걸릴 수 있습니다."):
                auto_train_if_needed(BASE_DIR, epochs=100, imgsz=384, base_model="yolo11s-cls.pt", force_train=True, patience=20)
            st.success("학습 완료. 페이지를 새로고침하세요.")
        st.stop()

    mode = st.radio(
        "사용 방법을 선택하세요.",
        ["이미지 업로드", "카메라 촬영", "실시간 웹캠"],
        horizontal=True,
    )

    if mode == "이미지 업로드":
        st.subheader("이미지 업로드로 판정")

        uploaded = st.file_uploader(
            "재활용 쓰레기 이미지를 업로드하세요.",
            type=["jpg", "jpeg", "png", "webp"],
        )

        if uploaded is None:
            st.info("이미지를 업로드하면 중앙 영역만 잘라서 분석합니다.")
        else:
            pil_img = Image.open(uploaded)
            analyze_and_show_image(
                pil_img=pil_img,
                material_model=material_model,
                contamination_model=contamination_model,
                roi_scale=roi_scale,
                roi_x_offset=roi_x_offset,
                roi_y_offset=roi_y_offset,
                min_model_conf=min_model_conf,
                use_object_crop=use_object_crop,
            )

    elif mode == "카메라 촬영":
        st.subheader("카메라 촬영으로 판정")
        st.write("물체 하나를 중앙에 크게 맞춘 뒤 촬영하세요.")

        camera_file = st.camera_input("재활용품을 중앙에 놓고 촬영하세요.")

        if camera_file is None:
            st.info("브라우저에서 카메라 권한을 허용한 뒤 촬영하세요.")
        else:
            pil_img = Image.open(camera_file)
            analyze_and_show_image(
                pil_img=pil_img,
                material_model=material_model,
                contamination_model=contamination_model,
                roi_scale=roi_scale,
                roi_x_offset=roi_x_offset,
                roi_y_offset=roi_y_offset,
                min_model_conf=min_model_conf,
                use_object_crop=use_object_crop,
            )

    else:
        st.subheader("실시간 웹캠으로 판정")
        st.write("물체 하나를 화면 중앙 초록색 박스 안에 넣으세요.")

        camera_index = st.number_input(
            "카메라 번호",
            min_value=0,
            max_value=5,
            value=0,
            step=1,
        )

        run = st.checkbox("웹캠 켜기")

        frame_box = st.empty()
        result_box = st.empty()
        table_box = st.empty()

        if run:
            cap = cv2.VideoCapture(int(camera_index))

            if not cap.isOpened():
                st.error("웹캠을 열 수 없습니다. 다른 프로그램이 카메라를 사용 중인지 확인하세요.")
            else:
                st.info("웹캠을 끄려면 체크박스를 해제하세요.")

                while run:
                    ret, frame = cap.read()

                    if not ret:
                        st.error("카메라 화면을 읽지 못했습니다.")
                        break

                    crop, box, crop_reason = find_object_crop(frame, roi_scale, roi_x_offset, roi_y_offset, use_object_crop)
                    crop = preprocess_crop(crop)

                    result = analyze_crop(
                        crop_bgr=crop,
                        material_model=material_model,
                        contamination_model=contamination_model,
                        min_model_conf=min_model_conf,
                    )

                    annotated = draw_roi(
                        frame,
                        box,
                        label=f"{result.material} / {result.contamination}",
                    )

                    frame_box.image(
                        bgr_to_pil(annotated),
                        use_container_width=True,
                    )

                    material_kor = MATERIAL_LABELS_KOR.get(result.material, result.material)
                    contamination_kor = CONTAMINATION_LABELS_KOR.get(result.contamination, result.contamination)

                    msg = f"재질: {material_kor} / 오염도: {contamination_kor} / 배출: {result.route}"

                    if result.contamination == "dirty":
                        result_box.error(msg)
                    elif result.contamination == "clean":
                        result_box.success(msg)
                    else:
                        result_box.warning(msg)

                    table_box.dataframe(
                        pd.DataFrame([
                            {
                                "재질": material_kor,
                                "재질 신뢰도": round(result.material_confidence, 3),
                                "오염도": contamination_kor,
                                "오염도 신뢰도": round(result.contamination_confidence, 3),
                                "배출 방법": result.route,
                            }
                        ]),
                        use_container_width=True,
                    )

                    time.sleep(0.12)

                cap.release()

    with st.expander("사용 방법"):
        st.write(
            """
            1. ZIP 파일들과 이 파이썬 파일을 같은 폴더에 둡니다.
            2. `python recycle_all_in_one_complete_v6.py`로 실행합니다.
            3. 첫 실행 때 자동 학습이 진행됩니다.
            4. 학습이 끝나면 앱이 자동으로 열립니다.
            5. 물체 하나를 중앙 초록색 박스 안에 크게 넣고 촬영합니다.
            """
        )


# ============================================================
# 실행 진입점
# ============================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=80, help="자동 학습 epoch 수. 정확도 우선 기본값은 80입니다.")
    parser.add_argument("--imgsz", type=int, default=384)
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--base-model", type=str, default="yolo11s-cls.pt", help="정확도 우선 기본값은 yolo11s-cls.pt입니다. 빠른 테스트는 yolo11n-cls.pt")
    parser.add_argument("--patience", type=int, default=20, help="성능 개선이 없을 때 조기 종료할 epoch 수")
    parser.add_argument("--force-train", action="store_true", help="기존 모델이 있어도 다시 학습")
    parser.add_argument("--no-train", action="store_true", help="자동 학습을 건너뛰고 앱만 실행")
    parser.add_argument("--train-only", action="store_true", help="학습만 진행하고 Streamlit 앱은 실행하지 않음")
    return parser.parse_args()


def main() -> None:
    if is_running_in_streamlit():
        streamlit_app()
        return

    args = parse_args()

    train_ok = True

    if not args.no_train:
        try:
            auto_train_if_needed(
                zip_dir=BASE_DIR,
                epochs=args.epochs,
                imgsz=args.imgsz,
                batch=args.batch,
                base_model=args.base_model,
                force_train=args.force_train,
                patience=args.patience,
            )
        except Exception as e:
            train_ok = False
            print("\n[자동 학습 실패]")
            print(e)
            print("\n학습 실패 상태에서는 기존 모델을 그대로 쓰거나 앱 정확도가 낮아질 수 있습니다.")

    if args.train_only:
        if train_ok:
            print("\n[학습 전용 모드 종료] 학습이 끝났으므로 앱은 실행하지 않습니다.")
        else:
            print("\n[학습 전용 모드 종료] 학습 실패 내용을 확인한 뒤 다시 실행하세요.")
        return

    if not train_ok and not MATERIAL_MODEL_PATH.exists():
        print("\n[앱 실행 중단] 재질 모델이 없고 학습도 실패했습니다. 문제를 해결한 뒤 다시 실행하세요.")
        return

    script_path = Path(__file__).resolve()

    print("\n[앱 실행]")
    subprocess.run([sys.executable, "-m", "streamlit", "run", str(script_path)])


if __name__ == "__main__":
    main()
